const express = require('express')
const router = express.Router()
const { addProducts, getAddedProducts } = require('../controller/productController')

router.post('/add', addProducts)
router.get('/', getAddedProducts)

module.exports = router